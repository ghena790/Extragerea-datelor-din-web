<?php

function view($html, $params = [])
{
    foreach ($params as $key => $value) {
        ${$key} = $value;
    }
    include(dirname(__FILE__) . '/views/' . $html . '.php');
}