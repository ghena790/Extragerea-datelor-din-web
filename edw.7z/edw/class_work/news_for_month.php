<?php
require __DIR__ . "/vendor/autoload.php";
require __DIR__ . "/config.php";

use Goutte\Client;
use Symfony\Component\DomCrawler\Crawler;
use Symfony\Component\HttpClient\HttpClient;

// $client = new Client();
$client = new Client(HttpClient::create(['verify_peer' => false, 'verify_host' => false]));
// Crawler
$crawler = $client->request('GET', 'https://stopfals.md/ro/category/29');
//Parser
$newsContainer = $crawler->filter('#latest-falses');
$news = [];
$newsContainer->children()->each(function (Crawler $node, $i) use (&$news) {
    $news[] = [
        'data'  => $node->filter('.date')->eq(0)->text(),
        'views' => $node->filter('.views')->eq(0)->text(),
        'title' => $node->filter('.title')->eq(0)->text(),
        'url' => $node->filter('.title')->link()->getUri(),
        'image' => '...',
        'abstract'  => ''
    ];
});

view('stop_fals', [
    'header' =>  'Falsurile lunii',
    'news'  => $news
]);
// echo "<pre>";
// var_dump($news);
// echo '</pre>';