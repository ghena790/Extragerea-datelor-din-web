<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Web Scrapper</title>
</head>

<body>
<h1><?= $header; ?></h1>
<div class="container">
    <?php for ($i = 0; $i < count($news); $i++) { ?>
        <div class="card">
            <h5 class="card-header">
                Data: <?= $news[$i]['data'] ?> <span class="badge bg-secondary">Visits: <?= $news[$i]['views'] ?></span>
            </h5>
            <div class="card-body">
                <h5 class="card-title"><?= $news[$i]['title'] ?> </h5>
                <p class="card-text">
                    <?= $news[$i]['abstract'] ?>
                </p>
                <a href="<?= $news[$i]['url'] ?>" class="btn btn-primary">Visit</a>
            </div>
        </div>
    <?php } ?>
</div>


<!--JQuery-->
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>